# Tower Siege Game
 
## How do I play this game?
Drag the hexagonal stone, aim it properly, and release it at the blocks! Watch and enjoy how the objects move like real-life objects.

## What is the maximum number of points I can get?
You can get upto __360__ points.

## Oh no! I missed some of the blocks. How do I get another chance to play?
Press the space key for another chance.

## Why is the background changing?
The background changes according to the **IST** timezone. It is a bright, sunny background from 6:00 AM to 7:00 PM, and a beautiful, starry night during other times.

# Thank you for playing this game, I hope you enjoy it! 😊
